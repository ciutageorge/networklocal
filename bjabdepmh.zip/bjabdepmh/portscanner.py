import socket
import threading
from queue import Queue

# Se alege locatia dorita
target = '192.168.122.72'
queue = Queue
open_ports = []

# Initializatrea portului
def portscan(port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((target, port))
        return True
    except:
        return False

#Verificarea portului manual
#print (portscan(23))

#Verificarea porturilor printr-un range necesita un timp ridicat
#for port in range(20, 30):
#    result = portscan(port)
#    if result:
#       print("Portul {} este deschis !".format(port))
#    else:
#        print("Portul {} este inchis  !".format(port))

def fill_queue(port_list):
    for port in port_list:
        queue.put(port)

def worker():
    while not queue.empty():
        port = queue.get()
        if portscan(port):
            print ("Port {} este deschis".format(port))
            open_ports.append(port)

    port_list = range(1, 1024)
    fill_queue(port_list)

thread_list = []

for t in range(500):
    thread = threading.Thread(target=worker)
    thread_list.append(thread)

for thread in thread_list:
    thread.start()

for thread in thread_list:
    thread.join()

print ('Porturile deschise sunt: ', open_ports)