import requests
import json

url = 'http://localhost'

r = requests.get(url)
#url = "http://localhost:3080/v2/projects/13ced59c-7596-4787-bd71-091c2e2c0609/nodes/f18a1310-b427-4443-b213-57cdad4e33de/stop"


